# RocketMQ-Spark

To integrate RocketMQ with Spark or Spark Streaming, see [RocketMQ + Spark Streaming Integration Guide](./spark-streaming-rocketmq.md).

To integrate RocketMQ with Spark SQL or Spark Structured Streaming, see [RocketMQ + Spark Structured Streaming Integration Guide](./spark-structured-streaming-rocketmq.md).
