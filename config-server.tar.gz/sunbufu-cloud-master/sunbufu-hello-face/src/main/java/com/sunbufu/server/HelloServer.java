package com.sunbufu.server;

public interface HelloServer {

    /**
     * 返回"hello,${name}"
     */
    String hello(String name);

}
